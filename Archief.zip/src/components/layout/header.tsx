/**
 * Component responsible for rendering the Search Bar
 */
import React from 'react';

const Header: React.FC = () => {
  return <header>
    <h1>Schiphol</h1>
  </header>
}

export default Header;