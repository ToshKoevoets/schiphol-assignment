/**
 * Component responsible for rendering the Search Bar
 */
import React from 'react';
import PropTypes, { InferProps } from 'prop-types';
import SearchFlightItem from './SearchFlightItem';
// import { Flight } from '../../types/Flight';
import SearchNoResults from './SearchNoResults';

const propTypes = {
  flights: PropTypes.array.isRequired,
};

//: [Flight] type not possible  in this case?

type ComponentTypes = InferProps<typeof propTypes>;

const SearchList: React.FC<ComponentTypes> = ({ flights }) => {
  return <div className="search-list">
    {flights.length > 0 ?
      <>
        {flights.map((flight, index) => {
          return <SearchFlightItem
            flightNumber={flight.flightNumber}
            flightIdentifier={flight.flightIdentifier}
            airport={flight.airport}
            expectedTime={flight.expectedTime}
            originalTime={flight.originalTime}
            url={flight.url}
          />
        })}
      </>
      :
      <SearchNoResults />
    }
  </div>
}

export default SearchList;