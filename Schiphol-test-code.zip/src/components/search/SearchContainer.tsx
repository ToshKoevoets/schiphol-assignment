/**
 * Component responsible for rendering the Search Bar
 */
import React, { useEffect, useState } from 'react';
import FlightsService from '../../services/FlightsService';
import { Flight } from '../../types/Flight';
import SearchList from './SearchList';
import SearchBar from './SearchBar';

const SearchContainer: React.FC = () => {
  const [flights, setFlights] = useState<Flight[] | []>([]);

  
  const getFlights = async () => {
    try {
      const flights = await FlightsService.getFlights();
      setFlights(flights);
    } catch (e) {
      console.log(e);
    }
  }

  /**
   * Get All Flights on Component Mount
   */
  useEffect(() => { 
    getFlights();
  }, []);

  /*
    @todo: implement search term & filter
    @todo: implement sort by

    setSearchTerm={() => {
      console.log('implement search term');
    }} 
  */

  console.log('Flights: ', flights);


  return <div className="search-container">
      <SearchBar 
        setSearchTerm={() => {
          console.log('implement search term');
        }}
      />
      <SearchList flights={flights} />
  </div> 
}

export default SearchContainer;