/**
 * Component responsible for rendering the Search Bar
 */
import React from 'react';
import PropTypes, { InferProps } from 'prop-types';
import './search-flight-item.css';

const propTypes = {
  setSearchTerm: PropTypes.func.isRequired,
};

type ComponentTypes = InferProps<typeof propTypes>;

const SearchBar: React.FC<ComponentTypes> = ({ setSearchTerm }) => {
  return <div className="search-bar">
    <label>
      <h1> Search:</h1>
      <input
        type="text"
        onChange={(e) => {
          setSearchTerm(e.target.value)
        }}
      />
    </label>
  </div>
}

export default SearchBar;