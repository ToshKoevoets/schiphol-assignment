/**
 * Service for interacting with the flights API
 */
import { Flight } from "../types/Flight";

export default class FlightsService {
  private static apiBase = '/api';

  static getFlights(): Promise<Flight[]> {
    return fetch(`${this.apiBase}/flights`)
      .then(data => data.json())
  }
}
